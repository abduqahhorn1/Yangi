def Triangle(son):
    s = ((3**0.5) / 4) * (son**2)
    p = 3*son
    print("s =",s,"  p =",p)

Triangle(int(input("A ga qiymat kiriting: ")))
Triangle(int(input("B ga qiymat kiriting: ")))
Triangle(int(input("C ga qiymat kiriting: ")))
