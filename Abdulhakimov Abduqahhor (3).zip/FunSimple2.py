A = float(input("A ga qiymat bering: "))
B = float(input("B ga qiymat bering: "))
C = float(input("C ga qiymat bering: "))

def PowerA234(son):
    ikki = son ** 2
    uch = son ** 3
    tort = son ** 4
    print(son,"^ 2 =",ikki,"  ",son,"^ 3 =",uch,"   ",son,"^ 4 =",tort)

PowerA234(A)
PowerA234(B)
PowerA234(C)
