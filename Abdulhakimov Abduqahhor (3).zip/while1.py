a = int(input("A ga qiymat kiriting: "))
b = int(input("B ga qiymat kiriting: "))

while a>=b:
    a -= b
print(a)