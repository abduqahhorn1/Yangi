list_1 = ["name", "age", "surname", "address"]
list_2 = ["Anvar", 17, "Sobirov", "Fergana"]

new_dict = {list_1[1]: list_2[1], list_1[2]: list_2[2]}

print(new_dict)