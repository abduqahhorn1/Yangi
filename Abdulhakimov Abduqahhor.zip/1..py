a = {'number_1':1, 'number_2':2, 'number_3':3, 'number_4':4}

for key in a:
    a[key] = False

print(a)