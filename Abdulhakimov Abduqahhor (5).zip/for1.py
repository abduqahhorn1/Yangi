k = int(input("Sonni kiriting: "))
n = int(input("Chiqarishlar sonini kiriting: "))

for i in range(n):
    print(k)