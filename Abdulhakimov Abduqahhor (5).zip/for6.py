narx = 2.5  
for i in range(12, 21, 2):
    print(f"{i/10} kg konfet narxi: {narx * i/10} so'm")