a = int(input("a ni kiriting: "))
b = int(input("b ni kiriting: "))

count = 0
for i in range(a, b+1):
    print(i)
    count += 1

print(f"Natijada {count} ta son chiqarildi.")