def print_numbers(n):
    if n >= 100:
        print("100 dan kichik son kiriting")
    else:
        i = 1
        while i <= n:
            print(i)
            i += 1
 
print_numbers(10) # 1 dan 10 gacha sonlar chiqadi

print_numbers(105)  # 100 dan kichik sonni kiriting