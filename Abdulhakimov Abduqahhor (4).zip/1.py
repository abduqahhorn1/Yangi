def pow_number(a, b):
    return a ** b
r = pow_number(4,2)
print(r)