def print_arguments(*args, **kwargs):
    print("Positional arguments:")
    for arg in args:
        print(arg)
    print("Keyword arguments:")
    for key, value in kwargs.items():
        print(f"{key} = {value}")
print_arguments(1, 2, 'apple', 'salom', name='Ali', age=25)